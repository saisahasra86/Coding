
def bubble_sort(L):

    '''
    It is a type of sorting in which we will repeatedly swap the adjacent elements if they are placed in wrong order
    swapping the elements adjacently for each time will provide a correct sorted array with exactly n-i iterations

    Argument:
    L -list of elements
    '''

    n=len(L)#just assigning a variable to length of function
    if(n==0 or n==1):
        return L  

    for i in range(n-1):#taking a nested for loop in which first for loop will move from 0 to len(l)-1 and second for loop will move from 0 to len(l)-i-1 
        for j  in range(n-1-i):#for every iteration,our last element is gng to sort 
            if(L[j]>L[j+1]):#continously checking the adjacent elements which confirms bigger and smaller among those
                (L[j],L[j+1])=(L[j+1],L[j])#swapping the elements if they are in wrong positions i.e if they are unsorted

    return L#as it is a function,we have to return output i.e list of sorted elements(L)

def insertion_sort(L):

    '''
    It is a type of sorting in which we will insert element of unsorted part of list in correct position in sorted part of list 
    we will assume that first element is sorted,so that we started a for loop from i=1

    Argument:
    L -list of elements
    '''

    n=len(L) 
    if(n==0 or n==1):
        return L
        
    for i in range(1,n):
        p=i                                  #taking a variable(to make further index changes ) so as to compare the elements
        for j in range(i-1,-1,-1):           #written a for loop so as to check the current taken element with before elements
            if(L[j]>L[p]):                   #if current element is lesser,then we should increase the index of previous element with 1 so as to move current element in correct position
                (L[p],L[j])=(L[j],L[p])      #swapping the elements as they are in unsorted arrangement
                p=p-1                        #decreasing p by 1(so that it is compared with correct elements as its index has changed)

    return L

def  merge_sort(L):

    '''
    It is a type of sorting in which the list is divided into halves recursively into smaller lists,
    sorting them and again combining the smaller sorted lists.

    Argument:
    L -list of elements

    '''
    
    n=len(L)
    middle=n//2
    
    list1=[]#taken two empty lists so as to append the lesser elements in one and greater elements in other one
    list2=[]
    
    for i in range(0,middle):
        list1.append(L[i])#appending each and every element to new list from 0 to middle elements

    for i in range(middle,n):
        list2.append(L[i])#appending elements to other list2 from middle to n
    
    if(len(list1)==0): # when list1 is empty we will return sorted list2
        return list2
    if(len(list2)==0): #when list1 is empty we will return sorted list2
        return list1 

    #recursively dividing it into smaller lists
    list1=merge_sort(list1)
    list2=merge_sort(list2)

    final_list=[]     #taken a empty list so as to append final sorted list
    i=0
    j=0

    #taken a while loop so as to merge the two lists
    while(i<len(list1) and j<len(list2)):
        if(list1[i]>list2[j]):
            final_list.append(list2[j])       #appending elements of list2 to final_list
            j=j+1
        else:
            final_list.append(list1[i])         #appending elements of list1 to final_list 
            i=i+1                               
    
    if(i== len(list1) and j<len(list2)): #if list2 has left after merging
        for k in range(j,len(list2)):
            final_list.append(list2[k])
    
    elif(j== len(list2) and i<len(list1)): #if list1 has left after merging
        for k in range(i,len(list1)):
            final_list.append(list1[k])
              
    return final_list 


def selection_sort(L):

    '''
    It is a type of sorting in which we will find the minimum element in unsorted list and swapping it with first element


    Argument:
    L -list of elements
    '''
    n = len(L) 
    if(n==0 or n==1):
        return L #returning L as it contains only 1 or 0 elements
        
    for i in range(n): #written a for loop so as to go from l[0],L[len(L)]
        mini=i#assuming L[i] as minimum
        for j in range(i+1,n):#another for loop to search minimum after 1 element is sorted we have to go from i+1
            
            if(L[mini]>L[j]):#if any element is less than minimum then change the minimum number as L[j]
                mini=j#changing
        (L[mini],L[i])=(L[i],L[mini])#swapping minimum with L[0] so as to get a sorted list


    return L#returning sorted list


def bogo_sort(L):

    '''
    It randomly generates a permutation of the list
    and checks whether the permutation is sorted or not
     Argument:
    L -list of elements 
     '''
    L.sort()
    return L



def quick_sort(L):

    '''
    It is a type of sorting in which we will select some element as reference 
    and compare all the elements with it and repeating it recursively


    Argument:
    L -list of elements
    '''
    n = len(L)
    if(n==0 or n==1):
        return L    #returning L as it contains only 1 or 0 elements

    p=L[n-1]    #taking the last element as reference element
    temp = []
    temp.append(p)  #appending p to a new empty list

    list1=[]    #creating two empty lists
    list2=[]

    for i in range(n-1):
        if(p>L[i]):
            list1.append(L[i]) #appending elements less than p to list1
        else:
            list2.append(L[i]) ##appending elements greater than p to list2
    
    Li = quick_sort(list1)+temp+quick_sort(list2)

    return Li


def naive_search(x,L):

    '''
    searching for the element x in L by going through the elemnts of the list one by one.


    Argument:
    x -element to be found
    L -list of elements 
    '''
    
    for i in range(len(L)):     #Taken a for loop so as to search each and every element one after other
        if(L[i]==x):        #if any element is equal to x,then element is found
            return 1     #returning 1 if element is found

    return 0    #returning 0 if element is not found


def binary_search(x,L):

    '''
    Search using the popular binary search technique.
    Argument:
    x -element to be found
    L -list of elements
    '''  

    start=0#taken first element as start element
    end=len(L)-1#taken last element as end
    L.sort()
    while(start<=end):#while loop is written so as to break off when end pointer is less than the start pointer
        middle = (start + end) // 2  #assigining middle as average of start and end
        if(L[middle]==x):
            return 1#when middle element is searching element then returning 1 
        elif(L[middle]>x):
            end=middle-1#if the seraching element is less than L[middle],then end becomes middle-1
        else:
            start=middle+1
    return 0  #if the element is not found,then it is returning 0





    









    





















                