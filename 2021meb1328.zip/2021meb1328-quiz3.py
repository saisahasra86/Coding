dic1={'d':'r','r':'d','u':'l', 'l': 'u'}#written a dictionary(1) to directions when pattern is turned to anticlockwise with 90 degrees
dic2={'d':'d','r':'r','u':'u', 'l': 'l'}#written a dictionary(2) to directions when pattern is not rotated
dic3={'d':'l','r':'u','u':'r','l':'d'}#written a dictionary(3) to directions when pattern is turned to 90 degrees right

def ACW(l):#defining anticlockwise function as we are rotating it ACW in its first part
    list1=[]#assuming a empty list so as to append the elements according to dictionary-1 directions
    for i in range(len(l)):#writing a for loop so as to replace each and every element of l according to dictionary-3
        list1.append(dic1[l[i]])#appending
    return list1#as we are writing as funtions,we must have to return value


def no_rotation(l):#defining no_rotation function as we are not rotating the shape U 
    list2=[]#assuming a empty list so as to append the elements according to dictionary-2 directions
    for i in range(len(l)):#writing a for loop so as to replace each and every element of l according to dictionary-2
        list2.append(dic2[l[i]])#appending
    return list2#as we are writing as funtions,we must have to return value


def clockwise(l):#defining clockwise function as we are rotating it CW in its fourth part
    list3=[]#assuming a empty list so as to append the elements according to dictionary-3 directions
    for i in range(len(l)):#writing a for loop so as to replace each and every element of l according to dictionary-3
        list3.append(dic3[l[i]])#appending
    return list3#as we are writing as funtions,we must have to return value
def directions_to_cordinates(l):#defining function to convert directions to co-ordinates
    Li = [(1,1)] #basic U-shape starting from (1,1)
    for i in l:#written a for loop so as to convert each and every element of l to coordinates
        x,y = Li[len(Li)-1] #(x,y)be a last coordinate to whole U-shape 
        if(i=='d'): #if we  have to go down,x-coordinates must be increased by 1
            Li.append((x+1,y))    
        elif(i=='r'): #if we  have to go right,y-coordinates must be increased by 1 
            Li.append((x,y+1))
        elif(i=='u'): #if we  have to go Up,x-coordinates must be decreased by 1
            Li.append((x-1,y))
        else :
            Li.append((x,y-1))#if we have to go left,y-coordinates must be decreased by 1
    return Li#returning coordinates to respective directions

#defining SFC function so as to print directions according to dictinaries defined in order to turn it clockwise and anticlockwise directions

def SFC(n,l):#defining SFC
    if(n==1) :   #acc to our basic U-shape(down,right,up)
        return l #that is why we are returning l as 'dru'
    else :
        a= ACW(SFC(n-1,l))#our first part contains Ushape with a turn of 90 degrees over left side
        a.append('d')#here we are appending downward direction so as to join the other 3 parts with the first part
        b= no_rotation(SFC(n-1,l)) # our 3rd quadrant consists of only U-shape with no turns   
        b.append('r')#appending d(down)so as to join other part(3rd quadrant)  
        c= no_rotation(SFC(n-1,l))#our 4th quadrant consists of U-shape with no turns 
        c.append('u')#to attach other part ,appending u(up) 
        d= clockwise(SFC(n-1,l))#2nd qudrant having turn of 90 degrees over right in clockwise directions
        Li = a+b+c+d#concatenating all the lists in those four qudrants 
        output=directions_to_cordinates(Li)
        return output#as this is a function we have to return output


n=int(input())#giving input
l=['d','r','u']# l is the list which we are taking it as a basic pattern 
print(SFC(n,l))









 
    
       
        

      

       
     
 
      

   
        


    