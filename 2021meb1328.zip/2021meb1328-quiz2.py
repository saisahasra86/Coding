
# Name - Surkanti Sai Sahasra
# Roll No. - 2021MEB1328

# Program to build a snake with given no. of lines and curvature 

print("Enter number of lines and curvature")

# Taking input 
n= int(input())
c= float(input())

# integer dividing n into 2 parts for symmetry 
p = n//2

# Iterating over -n/2-1 to n/2 
for i in range(-1*(p+1),p):
    # if curvature is postive
    if(c >= 0) :
        # printing c*i^2 spaces and then *
        str = " "*(int(c*(i**2)))
        print(str+"*")

    else :
        # printing  int(abs(c)*((n**2)//4 - (i**2))) spaces 
        # because the apex of parabola we are constructing will be at max abs(c)*((n**2)//4 spaces when i=0
        # we start with zero gaps
        
        str = " "*int(abs(c)*((n**2)//4 - (i**2)))
        print(str+"*")